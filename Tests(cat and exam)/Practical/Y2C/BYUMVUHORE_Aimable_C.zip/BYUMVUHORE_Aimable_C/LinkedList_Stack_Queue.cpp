#include <iostream>
#include <list>
#include <stack>
#include <queue>

using namespace std;

void operateLinkedList() {
    list<int> linkedList;

    // Add nodes
    cout << "Enter value for node 1: ";
    int value;
    cin >> value;
    linkedList.push_back(value);

    cout << "Enter value for node 2: ";
    cin >> value;
    linkedList.push_back(value);

    cout << "Enter value for node 3: ";
    cin >> value;
    linkedList.push_back(value);

    cout << "Enter value for node 4: ";
    cin >> value;
    linkedList.push_back(value);

    // Sort elements
    linkedList.sort();

    // Delete the last element
    if (!linkedList.empty()) {
        linkedList.pop_back();
        cout << "Linked List after sorting its elements and deletion of the last element: ";
        for (int val : linkedList) {
            cout << val << " ";
        }
        cout << endl;
    } else {
        cout << "Linked list is empty!" << endl;
    }
}

void operateStack() {
    stack<int> stack;

    // Push elements
    cout << "Enter value to push onto stack: ";
    int value;
    cin >> value;
    stack.push(value);

    cout << "Enter value to push onto stack: ";
    cin >> value;
    stack.push(value);

    cout << "Enter value to push onto stack: ";
    cin >> value;
    stack.push(value);

    cout << "Enter value to push onto stack: ";
    cin >> value;
    stack.push(value);

    cout << "Enter value to push onto stack: ";
    cin >> value;
    stack.push(value);

    // Pop one element
    if (!stack.empty()) {
        stack.pop();
        cout << "Stack elements after 5 pushing and 1 pop operations: ";
        while (!stack.empty()) {
            cout << stack.top() << " ";
            stack.pop();
        }
        cout << endl;
    } else {
        cout << "Stack is empty!" << endl;
    }
}

void operateQueue() {
    queue<int> queue;

    // Add elements
    cout << "Enter value to add to queue: ";
    int value;
    cin >> value;
    queue.push(value);

    cout << "Enter value to add to queue: ";
    cin >> value;
    queue.push(value);

    cout << "Enter value to add to queue: ";
    cin >> value;
    queue.push(value);

    cout << "Enter value to add to queue: ";
    cin >> value;
    queue.push(value);

    cout << "Enter value to add to queue: ";
    cin >> value;
    queue.push(value);

    // Remove one element
    if (!queue.empty()) {
        queue.pop();
        cout << "Queue elements after 5 enqueue and 1 dequeue operations: ";
        while (!queue.empty()) {
            cout << queue.front() << " ";
            queue.pop();
        }
        cout << endl;
    } else {
        cout << "Queue is empty!" << endl;
    }
}

int main() {
    int choice;

    do {
        cout << "Enter your choice:" << endl;
        cout << "1. Operate on Linked List," << endl;
        cout << "2. Operate on Stack," << endl;
        cout << "3. Operate on Queue," << endl;
        cout << "0. Exit" << endl;

        cin >> choice;

        switch (choice) {
            case 1:
                operateLinkedList();
                break;
            case 2:
                operateStack();
                break;
            case 3:
                operateQueue();
                break;
            case 0:
                cout << "Exit program..." << endl;
                break;
            default:
                cout << "Invalid choice. Please enter again." << endl;
        }
    } while (choice != 0);

    return 0;
}
